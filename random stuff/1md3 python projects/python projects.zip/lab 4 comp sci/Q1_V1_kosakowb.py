#Bartosz Kosakowski
#400028494
#Lab 4 Question 1
##################

def one_mode(l: 'list of numbers'):
    numList = sorted(l,reverse=True)
    modeCount = []
    z = {}
    for i in range(len(numList)):
        y = numList.count(numList[i])
        x = numList[i]
        modeDict[x] = y
    for j in range(len(numList)):
        maxCount = numList[0]
        if 
    for key in modeDict:
        if [modeDict[key]
    
        
