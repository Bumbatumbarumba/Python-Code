#Bartosz Kosakowski
#400028494
#Lab 2 Question 1
#####################
def salmaJump(easyQ, hardQ):
    totalJumps = easyQ + 3*hardQ
    return totalJumps
