#Bartosz Kosakowski
#400028494
#Lab 2 Question 6
#####################
def elmCount(elmStr: 'enter a sentence'):
    numElm = elmStr.count("elm")
    return numElm
